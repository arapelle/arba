import os, re

from conan import ConanFile
from conan.tools.build import check_min_cppstd
from conan.tools.cmake import CMakeToolchain, CMake, cmake_layout, CMakeDeps
from conan.tools.files import load, copy, rmdir

required_conan_version = ">=2.2.0"

class SandTestRecipe(ConanFile):
    name = "sandtest"
    package_type = "application"

    # Binary configuration
    settings = "os", "compiler", "build_type", "arch"
    options = {
        "shared": [True, False],
        "fPIC": [True, False],
    }
    default_options = {
        "shared": True,
        "fPIC": True,
    }

    # Build
    win_bash = os.environ.get('MSYSTEM', None) is not None
    no_copy_source = True

    # Sources
    exports_sources = "CMakeLists.txt", "main.cpp", "cmake/*"

    # Other
    implements = ["auto_shared_fpic"]

    def set_version(self):
        self.version = "0.1.0"

    def layout(self):
        cmake_layout(self)

    def validate(self):
        check_min_cppstd(self, 20)
    
    def requirements(self):
        self.requires("arba-core/[^0.29]", transitive_headers=True, transitive_libs=True)
        self.requires("arba-stdx/[^0.2]", transitive_headers=True, transitive_libs=True)
        self.requires("arba-rand/[^0.2]", transitive_headers=True, transitive_libs=True)
        self.requires("onetbb/2021.12.0", transitive_libs=True)

    def generate(self):
        deps = CMakeDeps(self)
        deps.generate()
        tc = CMakeToolchain(self)
        tc.generate()

    def build(self):
        cmake = CMake(self)
        cmake.configure()
        cmake.build()

    def package(self):
        cmake = CMake(self)
        cmake.install()

    def package_info(self):
        self.cpp_info.set_property("cmake_target_name", self.name)
        self.cpp_info.libs = [self.name]
