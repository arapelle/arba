﻿#include <chrono>
#include <unordered_set>
#include <unordered_map>
#include <string>
#include <cassert>
#include <regex>
#include <cstddef>
#include <cstdint>
#include <iostream>
#include <format>
#include <span>
#include <ranges>
#include <algorithm>
#include <cstdlib>
#include <execution>

#include <arba/cppx/string/fixed_string.hpp>
#include <arba/stdx/container/span.hpp>
#include <arba/rand/rand.hpp>
#include <arba/rand/urng.hpp>
#include <arba/core/bit/htow.hpp>

using Duration = std::chrono::duration<float, ::std::chrono::milliseconds::period>;
using Clock = std::chrono::steady_clock;
using Time_point = std::chrono::time_point<Clock>;

// mv to arba-core
// mv span to arba-core

template <class CharT>
struct std::formatter<std::byte, CharT>
{
    template <class FormatParseContext>
    inline constexpr auto parse(FormatParseContext& ctx)
    {
        auto iter = ctx.begin();
        if (iter == ctx.end())
            return iter;
        constexpr std::array<CharT, 7> chs = {'u', 'i', 'x', 'b', 'o', 'c', '0'};
        constexpr uint8_t zero_ch_index = 6;
        auto find_iter = std::ranges::find(chs, *iter);
        if (find_iter == chs.end()) [[unlikely]]
            return iter;
        const uint8_t index = find_iter - chs.begin();
        if (index < zero_ch_index)
        {
            fmt_ = index;
            return ++iter;
        }
        ++iter;
        constexpr uint8_t nb_zero_reps = 5;
        const auto last_iter = chs.begin() + nb_zero_reps;
        find_iter = std::find(chs.begin(), last_iter, *iter);
        if (find_iter != last_iter)
        {
            fmt_ = (find_iter - chs.begin()) + zero_ch_index;
            ++iter;
        }
        return iter;
    }

    template <class FormatContext>
    auto format(const std::byte& arg, FormatContext& ctx) const
    {
        switch (fmt_)
        {
        case 0: // u
            return std::format_to(ctx.out(), "{}", static_cast<uint8_t>(arg));
        case 1: // i
            return std::format_to(ctx.out(), "{}", static_cast<int8_t>(arg));
        case 2: // x
            return std::format_to(ctx.out(), "{:02x}", static_cast<uint8_t>(arg));
        case 3: // b
            return std::format_to(ctx.out(), "{:08b}", static_cast<uint8_t>(arg));
        case 4: // o
            return std::format_to(ctx.out(), "{:03o}", static_cast<uint8_t>(arg));
        case 5: // c
            return std::format_to(ctx.out(), "{}", static_cast<char>(arg));
        case 6: // 0u
            return std::format_to(ctx.out(), "{:03d}", static_cast<uint8_t>(arg));
        case 7: // 0i
            return std::format_to(ctx.out(), "{:04d}", static_cast<int8_t>(arg));
        case 8: // 0x
            return std::format_to(ctx.out(), "0x{:02x}", static_cast<uint8_t>(arg));
        case 9: // 0b
            return std::format_to(ctx.out(), "0b{:08b}", static_cast<uint8_t>(arg));
        case 10: // 0o
            return std::format_to(ctx.out(), "0o{:03o}", static_cast<uint8_t>(arg));
        }
        throw std::runtime_error("Unrecognized byte formatting!");
    }

private:
    uint8_t fmt_ = 0;
};

constexpr std::string format_bytes(std::format_string<const std::byte&> fstr, std::span<const std::byte> bytes,
                                   std::size_t nb_elements_per_line, std::string_view prefix = "[\n", std::string_view suffix = "\n]")
{
    std::string res;
    if (bytes.empty()) [[unlikely]]
    {
        res.reserve(prefix.size() + suffix.size());
        res += prefix;
        res += suffix;
        return res;
    }
    res.reserve(bytes.size() * std::formatted_size(fstr, bytes.front())
                + bytes.size() / nb_elements_per_line
                + prefix.size() + suffix.size());
    res += prefix;
    std::size_t i = 0;
    for (const std::byte byte : bytes.first(bytes.size() - 1))
    {
        std::format_to(std::back_inserter(res), fstr, byte);
        ++i %= nb_elements_per_line;
        if (i == 0)
            res.push_back('\n');
    }
    std::format_to(std::back_inserter(res), fstr, bytes.back());
    res += suffix;
    return res;
}

constexpr std::string format_bytes(std::span<const std::byte> bytes,
                                   std::size_t nb_elements_per_line, std::string_view prefix = "[\n", std::string_view suffix = "\n]")
{
    return format_bytes("{:x} ", bytes, nb_elements_per_line, prefix, suffix);
}

constexpr std::string format_bytes(std::format_string<const std::byte&> fstr, std::span<const std::byte> bytes,
                                   std::string_view prefix = "[", std::string_view suffix = "]")
{
    return format_bytes(fstr, bytes, std::numeric_limits<std::size_t>::max(), prefix, suffix);
}

constexpr std::string format_bytes(std::span<const std::byte> bytes,
                                   std::string_view prefix = "[", std::string_view suffix = "]")
{
    return format_bytes(bytes, std::numeric_limits<std::size_t>::max(), prefix, suffix);
}

std::string make_regex_(std::string_view simple_regex_strv)
{
    std::string res;
    res.reserve(1024);
    for (char ch : simple_regex_strv)
    {
        switch (ch)
        {
        case 'a':
            res += "[a-z]";
            break;
        case '0':
            res += "[0-9]";
            break;
        }
    }
    return res;
}

class certified_string : public std::string
{
public:
    static const std::regex regex;
    explicit certified_string(std::string_view str)
        : std::string(str)
    {
        if (!std::regex_match(*this, regex))
            clear();
    }

//    template <unsigned REQUEST>
//    std::string_view get() const
//    {
//        auto [first, last] = fixed_indexes.template get<REQUEST>();
//        return std::string_view(c_str() + first, last - first);
//    }
};

template <cppx::fixed_string... Strings>
class string_sequence
{
public:
    static constexpr std::size_t size() noexcept { return sizeof...(Strings); }
    static constexpr std::array<std::string_view, size()> values = { Strings... };
};

template <typename ValueType, cppx::fixed_string... Keys>
class ckrv_map
{
public:
    using value_type = ValueType;
    using reference = std::add_lvalue_reference_t<value_type>;
    using const_reference = std::add_const_t<reference>;

    static constexpr std::size_t size() noexcept { return sizeof...(Keys); }
    static constexpr std::array<std::string_view, size()> keys = { Keys... };

    template <cppx::fixed_string Key>
    static constexpr std::size_t key_index()
    {
        auto iter = std::ranges::find(keys, Key);
        if (iter != keys.end()) [[likely]]
            return iter - keys.begin();
        return size();
    }

    template <cppx::fixed_string Key>
    requires (ckrv_map::key_index<Key>() < size())
        reference get()
    {
        constexpr std::size_t index = ckrv_map::key_index<Key>();
        return elements_[index];
    }

    template <cppx::fixed_string Key>
    requires (ckrv_map::key_index<Key>() < size())
    constexpr const_reference get() const
    {
        constexpr std::size_t index = ckrv_map::key_index<Key>();
        return elements_[index];
    }

private:
    std::array<value_type, size()> elements_;
};

struct simple_regex
{
    static constexpr char new_field_marker = '|';
    static constexpr char end_field_marker = '|';
    static constexpr char lower_marker = 'a';
    static constexpr char upper_marker = 'A';
    static constexpr char digit_marker = '0';
    static constexpr char letter_marker = 'L';
    static constexpr char alphanum_marker = 'N';
    static constexpr char lower_var_marker = 'v';
    static constexpr char var_marker = 'V';
//    static constexpr Map<char, "new_field_marker", "end_field_marker">;
};

const std::regex certified_string::regex = std::regex(make_regex_("|aaa||00|"));

std::span<std::byte> as_writable_bytes(uint64_t& arg)
{
    return std::span(reinterpret_cast<std::byte*>(&arg), sizeof(arg));
}

inline uint64_t xorshift_64(uint64_t x)
{
    x ^= x << 13;
    x ^= x >> 7;
    x ^= x << 17;
    return x;
}

inline uint64_t xorshift_64(uint64_t x, uint64_t times)
{
    for (; times; --times)
        x = xorshift_64(x);
    return x;
}

void addrot_fill(std::span<std::byte> bytes, std::size_t current_byte_size)
{
    constexpr std::size_t uint_size = sizeof(uintmax_t);
    assert(bytes.size() > current_byte_size);
    assert(current_byte_size >= uint_size);
    const std::span<uintmax_t> ints = stdx::as_writable_span<uintmax_t>(bytes);
    const uintmax_t ints_byte_size = ints.size_bytes();
    if (current_byte_size < (uint_size * 2))
    {
        if (ints.size() >= 2)
        {
            ints[1] = core::wtoh(xorshift_64(~xorshift_64(core::htow(ints[0]))));
            current_byte_size += uint_size;
        }
    }
    if (current_byte_size < ints_byte_size)
    {
        if (current_byte_size < (uint_size * 4))
        {
            if (ints.size() >= 3)
            {
                ints[2] = ~ints[0];
                ints[2] = core::wtoh(xorshift_64(~core::htow(ints[0])));
                current_byte_size += uint_size;
                if (ints.size() >= 4)
                {
                    ints[3] = ~ints[1];
                    ints[3] = core::wtoh(xorshift_64(core::htow(ints[1])));
                    current_byte_size += uint_size;
                }
            }
        }
        constexpr std::array primes = { 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 53, 59, 61 };
        for (auto primes_iter = primes.cbegin();
             current_byte_size < ints_byte_size && primes_iter != primes.cend();
             ++primes_iter)
        {
            const int rot = *primes_iter;
            const std::size_t max_size_to_copy = current_byte_size / uint_size;
            std::span output_ints = ints.subspan(max_size_to_copy);
            std::size_t size_to_copy = std::min(output_ints.size(), max_size_to_copy);
            const std::size_t off = std::distance(primes.cbegin(), primes_iter);
            std::span input_ints = stdx::as_writable_span<uintmax_t>(bytes.subspan(off)).first(size_to_copy);
            std::transform(std::execution::par, input_ints.begin(), input_ints.end(), output_ints.begin(),
                           [=](uintmax_t value){ return core::wtoh(std::rotl(core::htow(value), rot)); });
            if (current_byte_size += input_ints.size_bytes(); current_byte_size < ints_byte_size)
            {
                output_ints = output_ints.subspan(size_to_copy);
                size_to_copy = std::min(output_ints.size(), max_size_to_copy);
                input_ints = stdx::as_writable_span<uintmax_t>(bytes.subspan(off)).first(size_to_copy);
                std::transform(std::execution::par, input_ints.begin(), input_ints.end(), output_ints.begin(),
                               [=](uintmax_t value){ return core::wtoh(~std::rotr(0x0101010101010101+core::htow(value), rot)); });
                current_byte_size += input_ints.size_bytes();
            }
        }
    }
    if (current_byte_size < bytes.size())
    {
        const std::span output_bytes = bytes.subspan(current_byte_size);
        assert(output_bytes.size() < uint_size);
        const std::span input_bytes = bytes.first(output_bytes.size());
        std::ranges::transform(input_bytes, output_bytes.begin(), [=](std::byte value)
                               { return std::byte{std::rotr(static_cast<uint8_t>(value), 2)}; });
    }
}

void xorrot_fill(std::span<std::byte> bytes, std::size_t current_byte_size)
{
    constexpr std::size_t uint_size = sizeof(uintmax_t);
    assert(bytes.size() > current_byte_size);
    assert(current_byte_size >= uint_size);
    const std::span<uintmax_t> ints = stdx::as_writable_span<uintmax_t>(bytes);
    const uintmax_t ints_byte_size = ints.size_bytes();
    const std::span<uintmax_t> first_ints = ints.first(std::min(std::size_t(256), ints.size()));

    const uintmax_t seed = first_ints[0];
    std::array states = { seed, std::rotl(seed, 3), std::rotl(seed, 6), std::rotl(seed, 9),
                         ~seed, std::rotr(~seed, 3), std::rotr(~seed, 6), std::rotr(~seed, 9) };
    std::size_t i = 0;
    auto xorshift_fn = [&](uint64_t& val)
    {
        uint64_t& state = states[i++ & 7];
        state = xorshift_64(state);
        val = core::htow(state);
    };
    std::for_each(first_ints.begin(), first_ints.end(), xorshift_fn);

//    for (std::size_t idx = 0; uintmax_t& val : first_ints)
//        val = core::wtoh(xorshift_64(ints[idx++]));
    current_byte_size = first_ints.size_bytes();
    if (current_byte_size < ints_byte_size)
    {
        constexpr std::array primes = { /*3, 5, 7,*/ 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 53, 59, 61 };
        for (auto primes_iter = primes.cbegin();
             current_byte_size < ints_byte_size && primes_iter != primes.cend();
             ++primes_iter)
        {
            const int rot = *primes_iter;
            const std::size_t max_size_to_copy = current_byte_size / uint_size;
            std::span output_ints = ints.subspan(max_size_to_copy);
            std::size_t size_to_copy = std::min(output_ints.size(), max_size_to_copy);
            const std::size_t off = std::distance(primes.cbegin(), primes_iter);
            std::span input_ints = stdx::as_writable_span<uintmax_t>(bytes.subspan(off)).first(size_to_copy);
            std::transform(std::execution::par, input_ints.begin(), input_ints.end(), output_ints.begin(),
                           [=](uintmax_t value){ return core::wtoh(std::rotl(core::htow(value), rot)); });
            if (current_byte_size += input_ints.size_bytes(); current_byte_size < ints_byte_size)
            {
                output_ints = output_ints.subspan(size_to_copy);
                size_to_copy = std::min(output_ints.size(), max_size_to_copy);
                input_ints = stdx::as_writable_span<uintmax_t>(bytes.subspan(off)).first(size_to_copy);
                std::transform(std::execution::par, input_ints.begin(), input_ints.end(), output_ints.begin(),
                               [=](uintmax_t value){ return core::wtoh(~std::rotr(0x0C0C0C0C0C0C0C0C^core::htow(value), rot)); });
                current_byte_size += input_ints.size_bytes();
            }
        }
    }
    if (current_byte_size < bytes.size())
    {
        const std::span output_bytes = bytes.subspan(current_byte_size);
        assert(output_bytes.size() < uint_size);
        const std::span input_bytes = bytes.first(output_bytes.size());
        std::ranges::transform(input_bytes, output_bytes.begin(), [=](std::byte value)
                               { return std::byte{std::rotr(static_cast<uint8_t>(value), 2)}; });
    }
}

void print_algo_indexes(std::span<std::byte> bytes)
{
    std::array<uint64_t, 256> byte_counters;
    byte_counters.fill(0);
    for (std::byte val : bytes)
        ++byte_counters[static_cast<uint8_t>(val)];
    auto min_iter = std::ranges::min_element(byte_counters);
    auto max_iter = std::ranges::max_element(byte_counters);
//    std::cout << "min byte counter: " << std::distance(byte_counters.begin(), min_iter) << " -> " << *min_iter << std::endl;
//    std::cout << "max byte counter: " << std::distance(byte_counters.begin(), max_iter) << " -> " << *max_iter << std::endl;
    std::cout << "diff byte index: " << *max_iter - *min_iter << ", " << double(*max_iter) / *min_iter << std::endl;

    const std::span ints = stdx::as_writable_span<uintmax_t>(bytes);
    std::sort(std::execution::par, ints.begin(), ints.end());
    uint64_t max_count = 0;
    uint64_t count = 1;
    uint64_t i = 0;
    for (uint64_t val : ints.subspan(1))
    {
        if (val == ints[i++])
        {
            ++count;
        }
        else
        {
            max_count = std::max(count, max_count);
            count = 1;
        }
    }
    std::cout << "max_count: " << max_count << std::endl;
    auto uniq_iter = std::unique(ints.begin(), ints.end());
    std::cout << "diversity index: " << std::distance(ints.begin(), uniq_iter) / double(ints.size()) << std::endl;
}

struct xorshift_64_engine
{
public:
    explicit xorshift_64_engine(uint64_t seed_value = 0x7cc480b34a571804)
    {
        seed(seed_value);
    }

    void seed(uint64_t seed_value)
    {
        state_ = improve_seed(seed_value);
    }

    void discard(uint64_t nb)
    {
        state_ = xorshift_64(state_, nb);
    }

    uint64_t operator()() noexcept
    {
        return state_ = xorshift_64(state_);
    }

    static uint64_t improve_seed(uint64_t seed_value)
    {
        return xorshift_64(xorshift_64(seed_value) ^ 0b000000000'000000000'000000010'000000000'000000000'000000000'010000000'000000000, 4);
    }

private:
    uint64_t state_;
};

struct endianness_neutral_t {} endianness_neutral;
struct endianness_specific_t {} endianness_specific;

template <typename T>
concept EndiannessPolicy = std::is_same_v<T, endianness_neutral_t> || std::is_same_v<T, endianness_specific_t>;

void xorshift_64_random_fill(const std::span<std::byte> bytes, uint64_t seed, EndiannessPolicy auto policy)
{
    seed = xorshift_64_engine::improve_seed(seed);
    std::array states = { seed, std::rotl(seed, 3), std::rotl(seed, 6), std::rotl(seed, 9),
                         ~seed, std::rotr(~seed, 3), std::rotr(~seed, 6), std::rotr(~seed, 9) };
    std::size_t i = 0;
    auto xorshift_fn = [&](uint64_t& val)
    {
        uint64_t& state = states[i++ & 7];
        state = xorshift_64(state);
        if constexpr (std::is_same_v<decltype(policy), endianness_neutral_t>)
            val = core::htow(state); // make core::htow_if(state, policy);
        else
            val = state;
    };
    const std::span ints = stdx::as_writable_span<uintmax_t>(bytes);
    std::for_each(ints.begin(), ints.end(), xorshift_fn);

    std::size_t remaining_bytes = bytes.size() & 7;
    if (remaining_bytes > 0)
    {
        const std::span output_bytes = bytes.last(remaining_bytes);
        uint64_t state = core::htow(xorshift_64(states.front()));
        const std::span input_bytes = as_writable_bytes(state).first(remaining_bytes);
        std::ranges::copy(input_bytes, output_bytes.begin());
    }
}

void generate_random_unique_byte_index(auto o_iter, uint16_t n, uint64_t seed, EndiannessPolicy auto policy)
{
    if (n == 0) [[unlikely]]
        return;
    std::array<uint8_t, 256> iota;
    for (uint16_t i = 0; i < n; ++i)
        iota[i] = i;
    uint16_t iota_sz = n;
    std::array<uint8_t, 256> rnds;
    xorshift_64_random_fill(std::as_writable_bytes(std::span(rnds).first((n-1)/8+1)), seed, policy);
    for (uint16_t i = 0; i < n; ++i)
    {
        uint8_t idx = rnds[i] % iota_sz;
        uint8_t val = iota[idx];
        *o_iter++ = val;
        iota[idx] = iota[--iota_sz];
    }
    *o_iter = iota.front();
}

void swap_chunk_256_bytes(const std::span<std::byte> bytes, const std::span<uint8_t> indexes)
{
    assert(bytes.size() % 256 == 0 && bytes.size() > 0);
    assert(indexes.size() % 128 == 0 && indexes.size() > 0);
//    for (auto chunk_i : std::views::iota(0ull, bytes.size() / 256))
//    {
//        for (auto index : std::views::iota(0, 128))
//        {
//            const std::size_t circular_i = (index + chunk_i) % 128;
//            std::byte& l_byte = bytes[(chunk_i * 256) + (index * 2)];
//            std::byte& r_byte = bytes[(chunk_i * 256) + (indexes[circular_i] * 2) + 1];
//            std::swap(l_byte, r_byte);
//        }
//    }
    for (auto iter = bytes.begin(), end_iter = bytes.end(); iter != end_iter; iter += 2)
    {
        const std::size_t index = std::distance(&bytes.front(), &*iter);
        const std::size_t chunk_i = index / 256;
        const std::size_t circular_i = ((index/2) + chunk_i) % 128;
        std::byte& r_byte = bytes[(chunk_i * 256) + (indexes[circular_i] * 2) + 1];
        std::swap(*iter, r_byte);
    }
}

void swap_small_chunk_bytes(const std::span<std::byte> bytes, const std::span<uint8_t> indexes)
{
    assert(bytes.size() <= 256);
    assert((bytes.size() / 2) == indexes.size());

    for (auto iter = bytes.begin(), end_iter = iter + bytes.size();
         iter != end_iter;
         iter += 2)
    {
        const std::size_t index = std::distance(&bytes.front(), &*iter);
        std::byte& r_byte = bytes[indexes[index/2] * 2 + 1];
        std::swap(*iter, r_byte);
    }

    if (bytes.size() & 1 && indexes.back() & 1 && bytes.size() > 1)
        std::swap(bytes.back(), *(bytes.end() - 2));
}

void swap_bytes(const std::span<std::byte> bytes, uint64_t seed, EndiannessPolicy auto policy)
{
    std::span chunk_bytes = bytes.first((static_cast<std::size_t>(bytes.size() / 256)) * 256);
    assert(chunk_bytes.size() % 256 == 0);
    std::array<std::uint8_t, 128> indexes;

    if (chunk_bytes.size() > 0)
    {
        generate_random_unique_byte_index(indexes.begin(), indexes.size(), seed, policy);
        assert(std::unordered_set<std::uint8_t>(indexes.cbegin(), indexes.cend()).size() == 128);
        std::cout << format_bytes("{:0u}     ", std::as_bytes(std::span(indexes)), 16) << std::endl;
        swap_chunk_256_bytes(chunk_bytes, indexes);
    }

    std::size_t remaining_byte_count = bytes.size() % 256;
    if (remaining_byte_count > 0)
    {
        assert(false);
        generate_random_unique_byte_index(indexes.begin(), remaining_byte_count / 2, ~seed, policy);
        assert(std::unordered_set<std::uint8_t>(indexes.cbegin(), indexes.cbegin() + remaining_byte_count / 2).size() == remaining_byte_count / 2);
        swap_small_chunk_bytes(bytes.last(remaining_byte_count), indexes);
    }
}

int main()
{
//    std::array<std::uint8_t, 256> sw_ints;
//    std::span sw_bytes = std::as_writable_bytes(std::span(sw_ints));
//    for (uint16_t i = 0; i < sw_bytes.size(); ++i)
//        sw_ints[i] = i;
//    std::cout << format_bytes("{:0u} ", sw_bytes, 32) << std::endl;
//    swap_bytes(sw_bytes, 42, endianness_neutral);
//    std::cout << format_bytes("{:0u} ", sw_bytes, 32) << std::endl;
//    assert(std::unordered_set<std::uint8_t>(sw_ints.cbegin(), sw_ints.cend()).size() == sw_ints.size());
//    return 0;

    Time_point start_time_point;
    Duration duration;
    const std::size_t data_byte_size = /*2**/ 2*2* 2*1024;
//    const std::size_t data_byte_size = 1024*1024*100;
//    const std::size_t data_byte_size = 1024*1024*1024;
    std::cout << "data_size: " << "bytes=" << data_byte_size << " ints=" << (data_byte_size / 8) << " Mb=" << (data_byte_size /1024/1024) << std::endl;
    std::vector<std::byte> data(data_byte_size, std::byte{0});
    std::span bytes(data);
    const std::span ints = stdx::as_writable_span<uintmax_t>(bytes);

//    const uint64_t seed = 0b10100000000000;
//    rotl/rotr -> rotl/~rotr -> rotl/~++rotr -> rotl/~0x01...+rotr -> rotl/~0x0C...^rotr
//    const uint64_t seed = 0x0318141cbc869599;  // 100Mb (64.6179 -> 6.64417 -> 3.14572 -> 1.18374); rot_fill2 (1.06236)
//    const uint64_t seed = 0x201318caed9619c0;  // 100Mb (9.09747 -> 3.06519 -> 1.87152 -> 1.06661); rot_fill2 (1.04219)
//    const uint64_t seed = 0xecf09ba16c378067;  // 100Mb (8.32117 -> 3.09083 -> 2.16369 -> 1.24767); rot_fill2 (1.05568)
//    const uint64_t seed = 0x7cc480b34a571804;  // 100Mb (5.34056 -> 2.87576 -> 1.97637 -> 1.08613 -> 1.03377); rot_fill2 (1.06215)
    const uint64_t seed = rand::rand_u64();
    std::cout << std::format("seed: 0x{:016x}", seed) << std::endl;
    ints.front() = seed;

    std::cout << "------------------------------------------------------------------------" << std::endl;
    std::cout << "Chrono '" << "addrot_fill " << "' start!" << std::endl;
    start_time_point = Clock::now();
    {
        addrot_fill(std::as_writable_bytes(std::span(bytes)), 8);
    }
    duration = std::chrono::duration_cast<Duration>(Clock::now() - start_time_point);
    std::cout << "Chrono '" << "addrot_fill" << "' = " << duration.count() << "ms" << std::endl;
    print_algo_indexes(bytes);

    std::cout << "------------------------------------------------------------------------" << std::endl;
    std::cout << "Chrono '" << "xorrot_fill par" << "' start!" << std::endl;
    start_time_point = Clock::now();
    {
        xorrot_fill(std::as_writable_bytes(std::span(bytes)), 8);
    }
    duration = std::chrono::duration_cast<Duration>(Clock::now() - start_time_point);
    std::cout << "Chrono '" << "xorrot_fill par" << "' = " << duration.count() << "ms" << std::endl;
    print_algo_indexes(bytes);

    std::cout << "------------------------------------------------------------------------" << std::endl;
    std::cout << "Chrono '" << "xorshift_64" << "' start!" << std::endl;
    start_time_point = Clock::now();
    {
        uint64_t state = seed;
        for (uint64_t& val : ints)
        {
            state = xorshift_64(state);
            val = core::htow(state);
        }
    }
    duration = std::chrono::duration_cast<Duration>(Clock::now() - start_time_point);
    std::cout << "Chrono '" << "xorshift_64" << "' = " << duration.count() << "ms" << std::endl;
    print_algo_indexes(bytes);

    std::cout << "------------------------------------------------------------------------" << std::endl;
    std::cout << "Chrono '" << "xorshift_64 multiseed" << "' start!" << std::endl;
    start_time_point = Clock::now();
    {
        std::array states = { seed, std::rotl(seed, 3), std::rotl(seed, 6), std::rotl(seed, 9),
                             ~seed, std::rotr(~seed, 3), std::rotr(~seed, 6), std::rotr(~seed, 9) };
        std::size_t i = 0;
        auto xorshift_fn = [&](uint64_t& val)
        {
            uint64_t& state = states[i++ & 7];
            state = xorshift_64(state);
            val = core::htow(state);
        };
        std::for_each(ints.begin(), ints.end(), xorshift_fn);
    }
    duration = std::chrono::duration_cast<Duration>(Clock::now() - start_time_point);
    std::cout << "Chrono '" << "xorshift_64 multiseed" << "' = " << duration.count() << "ms" << std::endl;
    print_algo_indexes(bytes);

    std::cout << "------------------------------------------------------------------------" << std::endl;
    std::cout << "Chrono '" << "xorshift_64_random_fill" << "' start!" << std::endl;
    start_time_point = Clock::now();
    {
        xorshift_64_random_fill(bytes, seed, endianness_neutral);
    }
    duration = std::chrono::duration_cast<Duration>(Clock::now() - start_time_point);
    std::cout << "Chrono '" << "xorshift_64_random_fill" << "' = " << duration.count() << "ms" << std::endl;
    print_algo_indexes(bytes);

    std::cout << "------------------------------------------------------------------------" << std::endl;
    std::cout << "Chrono '" << "rand::rand_u64" << "' start!" << std::endl;
    start_time_point = Clock::now();
    {
        for (uint64_t& val : ints.subspan(1))
            val = core::htow(rand::rand_u64());
    }
    duration = std::chrono::duration_cast<Duration>(Clock::now() - start_time_point);
    std::cout << "Chrono '" << "rand::rand_u64" << "' = " << duration.count() << "ms" << std::endl;
    print_algo_indexes(bytes);

//    std::cout << "------------------------------------------------------------------------" << std::endl;
//    std::cout << "Chrono '" << "iota" << "' start!" << std::endl;
//    start_time_point = Clock::now();
//    {
//        uint8_t i = 0;
//        for (uint8_t& val : stdx::as_writable_span<uint8_t>(bytes))
//            val = ++i;
//    }
//    duration = std::chrono::duration_cast<Duration>(Clock::now() - start_time_point);
//    std::cout << "Chrono '" << "iota" << "' = " << duration.count() << "ms" << std::endl;
//    print_algo_indexes(bytes);

//    certified_string id("ab789");
//    std::cout << id << std::endl;

//    ckrv_map<std::string, "local", "global"> f_map;
//    f_map.template get<"local">() = "local_element";
//    f_map.template get<"global">() = "global_element";

//    std::array<uint8_t, 72> arr;
//    std::cout << std::format("{}", std::byte{25}) << std::endl;
//    std::cout << std::format("{:u}", std::byte{25}) << std::endl;
//    std::cout << std::format("{:0u}", std::byte{250}) << std::endl;
//    std::cout << std::format("{:i}", std::byte{250}) << std::endl;
//    std::cout << std::format("{:0i}", std::byte{250}) << std::endl;
//    std::cout << std::format("{:x}", std::byte{250}) << std::endl;
//    std::cout << std::format("{:0x}", std::byte{250}) << std::endl;
//    std::cout << std::format("{:b}", std::byte{250}) << std::endl;
//    std::cout << std::format("{:0b}", std::byte{250}) << std::endl;
//    std::cout << std::format("{:o}", std::byte{250}) << std::endl;
//    std::cout << std::format("{:0o}", std::byte{250}) << std::endl;
//    std::cout << (std::format("{:c}", std::byte{250}) == "\372") << std::endl;
//    std::span bytes(std::as_bytes(std::span(arr)));
//    std::cout << format_bytes(bytes, 16) << std::endl;
    return EXIT_SUCCESS;
}
