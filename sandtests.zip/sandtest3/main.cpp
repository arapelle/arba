#include <iostream>
#include <thread>
#include <ranges>
#include <mutex>
#include <shared_mutex>
#include <future>
#include <vector>
#include <queue>
#include <chrono>
#include <functional>
#include <ratio>
#include <cassert>

template <intmax_t Cycle, intmax_t TimesPerCycle>
    requires (Cycle > 0 || TimesPerCycle > 0)
class frequency_ratio_constant : public std::ratio<Cycle, TimesPerCycle>
{
public:
    constexpr static std::chrono::nanoseconds period_duration()
    {
        constexpr std::chrono::nanoseconds ns(1'000'000'000 * Cycle / TimesPerCycle);
        return ns;
    }
};

template <intmax_t TimesPerSecond>
class hertz_constant : public frequency_ratio_constant<1, TimesPerSecond>
{
};

class frequency_ratio
{
public:
    constexpr frequency_ratio(int32_t cycle = 1, int32_t times_per_cycle = 1)
        : cycle_(cycle), times_per_cycle_(times_per_cycle)
    {
        if constexpr (!std::is_constant_evaluated())
        {
            assert(cycle > 0);
            assert(times_per_cycle > 0);
        }
    }

    inline constexpr int32_t cycle() const noexcept { return cycle_; }

    inline constexpr int32_t times_per_cycle() const noexcept { return times_per_cycle_; }

    inline constexpr std::chrono::nanoseconds period_duration() const noexcept
    {
        return std::chrono::nanoseconds(1'000'000'000 * cycle_ / times_per_cycle_);
    }

private:
    int32_t cycle_, times_per_cycle_;
};

class hertz
{
public:
    constexpr hertz(intmax_t times_per_cycle = 1)
        : times_per_cycle_(times_per_cycle)
    {
        if constexpr (!std::is_constant_evaluated())
        {
            assert(times_per_cycle > 0);
        }
    }

    inline constexpr intmax_t cycle() const noexcept { return 1; }

    inline constexpr intmax_t times_per_cycle() const noexcept { return times_per_cycle_; }

    inline constexpr std::chrono::nanoseconds period_duration() const noexcept
    {
        return std::chrono::nanoseconds(1'000'000'000 / times_per_cycle_);
    }

private:
    intmax_t times_per_cycle_;
};

template <class Type>
concept FrequencyConstant = requires
{
    { Type::period_duration() } -> std::same_as<std::chrono::nanoseconds>;
};

template <class Type>
concept Frequency = requires (const Type& arg)
{
    { arg.period_duration() } -> std::same_as<std::chrono::nanoseconds>;
};

template <class SelfType>
class metronome_base
{
public:
    using clock = std::chrono::steady_clock;
    using duration = clock::duration;

protected:
    metronome_base()
    {
    }

    const SelfType& self() const noexcept { return static_cast<const SelfType&>(*this); }

    SelfType& self() noexcept { return static_cast<SelfType&>(*this); }

public:
    bool start()
    {
        if (standby()) [[likely]]
        {
            start_tp_ = clock::now();
            return true;
        }
        return false;
    }

    [[nodiscard]] inline bool standby() const
    {
        return start_tp_.time_since_epoch() == duration::zero();
    }

    [[nodiscard]] inline bool started() const
    {
        return !standby();
    }

    inline void stop()
    {
        start_tp_ = clock::time_point();
    }

    inline void restart()
    {
        start_tp_ = clock::now();
    }

    bool sleep_this_thread()
    {
        const duration work_duration(clock::now() - start_tp_);
        const auto sleep_duration = self().period_duration() - work_duration;
        const bool do_sleep = sleep_duration > duration::zero();
        if (do_sleep) [[likely]]
            std::this_thread::sleep_for(sleep_duration);
        start_tp_ = clock::now();
        return do_sleep;
    }

    bool sleep_this_thread(duration& dt)
    {
        const duration work_duration(clock::now() - start_tp_);
        const auto sleep_duration = self().period_duration() - work_duration;
        const bool do_sleep = sleep_duration > duration::zero();
        if (do_sleep) [[likely]]
            std::this_thread::sleep_for(sleep_duration);
        const clock::time_point tp = clock::now();
        dt = tp - start_tp_;
        start_tp_ = tp;
        return do_sleep;
    }

    bool sleep_this_thread(duration& dt, duration& work_duration)
    {
        work_duration = clock::now() - start_tp_;
        const auto sleep_duration = self().period_duration() - work_duration;
        const bool do_sleep = sleep_duration > duration::zero();
        if (do_sleep) [[likely]]
            std::this_thread::sleep_for(sleep_duration);
        const clock::time_point tp = clock::now();
        dt = tp - start_tp_;
        start_tp_ = tp;
        return do_sleep;
    }

private:
    clock::time_point start_tp_;
};

template <class FrequencyType>
class metronome;

template <Frequency FrequencyType>
    requires (!FrequencyConstant<FrequencyType>)
class metronome<FrequencyType> : public metronome_base<metronome<FrequencyType>>
{
    using base_ = metronome_base<metronome<FrequencyType>>;

public:
    using typename base_::duration;
    using frequency = FrequencyType;
    static constexpr bool has_constant_frequency = false;

    explicit metronome(const frequency& freq = frequency(), bool start = true)
    {
        [[maybe_unused]] const bool freq_res = set_period_frequency(freq);
        assert(freq_res);
        if (start)
        {
            [[maybe_unused]] const bool start_res = this->start();
            assert(start_res);
        }
    }

    [[nodiscard]] inline const frequency& period_frequency() const noexcept { return frequency_; }

    bool set_period_frequency(frequency freq, bool update_period_duration = true)
    {
        if (this->standby()) [[likely]]
        {
            frequency_ = std::move(freq);
            if (update_period_duration) [[likely]]
                period_duration_ = freq.period_duration();
            return true;
        }
        return false;
    }

    bool update_period_duration()
    {
        if (this->standby()) [[likely]]
        {
            period_duration_ = frequency_.period_duration();
            return true;
        }
        return false;
    }

    inline const duration& period_duration() const { return period_duration_; }

private:
    duration period_duration_ = duration::zero();
    frequency frequency_;
};

template <Frequency FrequencyType>
    requires (!FrequencyConstant<FrequencyType>) && std::atomic<FrequencyType>::is_always_lock_free
class metronome<std::atomic<FrequencyType>> : public metronome_base<metronome<std::atomic<FrequencyType>>>
{
    using base_ = metronome_base<metronome<std::atomic<FrequencyType>>>;

public:
    using typename base_::duration;
    using frequency = std::atomic<FrequencyType>;
    static constexpr bool has_constant_frequency = false;

    explicit metronome(const frequency& freq = frequency(), bool start = true)
    {
        set_period_frequency(freq);
        if (start)
        {
            [[maybe_unused]] const bool start_res = this->start();
            assert(start_res);
        }
    }

    [[nodiscard]] inline const frequency& period_frequency() const noexcept { return frequency_; }

    bool set_period_frequency(const frequency& freq, bool = true)
    {
        const auto fr = freq.load();
        frequency_ = fr;
        period_duration_ = fr.period_duration();
        return true;
    }

    bool update_period_duration() { return true; }

    inline duration period_duration() const { return period_duration_.load(); }

private:
    std::atomic<duration> period_duration_ = duration::zero();
    frequency frequency_;

    static_assert(std::atomic<duration>::is_always_lock_free);
};

template <FrequencyConstant FrequencyType>
class metronome<FrequencyType> : public metronome_base<metronome<FrequencyType>>
{
    using base_ = metronome_base<metronome<FrequencyType>>;

public:
    using typename base_::duration;
    using frequency = FrequencyType;
    static constexpr bool has_constant_frequency = true;

private:
    static constexpr duration period_duration_ = frequency::period_duration();

public:
    explicit metronome(bool start = true)
    {
        if (start)
        {
            [[maybe_unused]] const bool start_res = this->start();
            assert(start_res);
        }
    }

    explicit metronome(frequency, bool start = true)
        : metronome(start)
    {
    }

    [[nodiscard]] inline const frequency& period_frequency() const noexcept { return frequency(); }

    [[nodiscard]] inline const duration& period_duration() const { return period_duration_; }
};

template <intmax_t Cycle, intmax_t TimesPerCycle>
using frequency_ratio_constant_metronome = metronome<frequency_ratio_constant<Cycle, TimesPerCycle>>;

template <intmax_t TimesPerSeconds>
using hertz_constant_metronome = metronome<hertz_constant<TimesPerSeconds>>;

using frequency_ratio_metronome = metronome<frequency_ratio>;
using hertz_metronome = metronome<hertz>;

using atomic_frequency_ratio_metronome = metronome<std::atomic<frequency_ratio>>;
using atomic_hertz_metronome = metronome<std::atomic<hertz>>;

class execution_token
{
public:
    enum status : uint8_t  //class stop_request_enumerator : public meta::enumerator<>...
    {
        ready = 1<<7,
        stop = 1<<6,
        pause = 1<<5,
        sync = 1<<1,
    };

    execution_token() {}

    [[nodiscard]] inline bool is_ready() const noexcept { return mask_ & ready; }
    [[nodiscard]] inline bool is_running_main() const noexcept { return mask_ == 0; }
    [[nodiscard]] inline bool is_running_side() const noexcept
    {
        const uint8_t mask = mask_.load();
        return mask > 0 && mask < stop;
    }
    [[nodiscard]] inline bool is_running() const noexcept { return mask_ < stop; }
    [[nodiscard]] inline bool is_stopping() const noexcept
    {
        const uint8_t mask = mask_.load();
        return (mask & stop) && mask < ready;
    }
    [[nodiscard]] inline bool is_active() const noexcept { return mask_ < ready; }
    [[nodiscard]] inline bool must_stop() const noexcept { return (mask_ & stop); }
    [[nodiscard]] inline bool must_pause() const noexcept
    {
        const uint8_t mask = mask_.load();
        return (mask & pause) && mask < stop;
    }
    [[nodiscard]] inline bool must_sync() const noexcept
    {
        const uint8_t mask = mask_.load();
        return (mask & sync) && mask < stop;
    }

    [[nodiscard]] inline bool start() noexcept
    {
        const uint8_t old = mask_.fetch_and(uint8_t(~ready));
        return old & ready;
    }

    inline void request_sync() noexcept { mask_ |= sync; }
    inline void request_pause() noexcept { mask_ |= pause; }
    [[nodiscard]] inline bool request_stop() noexcept
    {
        const uint8_t old = mask_.fetch_or(stop);
        return old < stop;
    }

    [[nodiscard]] inline bool consume_sync() noexcept
    {
        const bool res = must_sync();
        mask_ &= ~sync;
        return res;
    }
    inline void finish_pause() noexcept
    {
        assert(mask_ | pause);
        mask_ &= ~pause;
    }
    inline void finish_stop() noexcept
    {
        assert(is_stopping());
        mask_ &= static_cast<uint8_t>(~stop);
        mask_ |= ready;
    }

    [[nodiscard]] inline operator bool() const noexcept { return mask_ == 0; }

private:
    std::atomic_uint8_t mask_ = ready;
};

template <class ResourceGenerator, class FrequencyType = hertz>
    requires Frequency<FrequencyType>
    || (Frequency<typename FrequencyType::value_type>
        && std::same_as<FrequencyType, std::atomic<typename FrequencyType::value_type>>)
class resource_builder
{
public:
    using resource_generator = ResourceGenerator;
    using resource = std::invoke_result_t<ResourceGenerator>;
    using metronome_type = metronome<FrequencyType>;
    using frequency = FrequencyType;

    resource_builder(resource_generator generator, frequency freq, std::size_t max_available_resources, bool start = true)
        : metronome_(freq),
          generator_(std::move(generator)),
          max_available_resources_(std::max<std::size_t>(max_available_resources, 1))
    {
        if (start)
            this->start();
    }

    resource_builder(const resource_builder&) = delete;
    resource_builder& operator=(const resource_builder&) = delete;

    resource_builder(resource_builder&&) = default;
    resource_builder& operator=(resource_builder&&) = default;

    ~resource_builder()
    {
        stop();
    }

    resource request_resource()
    {
        std::unique_lock lock(mutex_);
        const auto pred = [this]{ return !available_resources_.empty(); };
        consume_cv_.wait(lock, pred);
        resource rsc = std::move(available_resources_.front());
        available_resources_.pop();
        lock.unlock();
        build_cv_.notify_one();
        return rsc;
    }

    void stop()
    {
        if (exec_token_.request_stop()) [[likely]]
        {
            //
            {
                std::unique_lock lock(mutex_);
                if (!available_resources_.empty())
                    available_resources_.pop();
            }
            build_cv_.notify_one();
            thread_.join();
            thread_ = std::thread();
            //
            exec_token_.finish_stop();
        }
    }

    void start()
    {
        if (exec_token_.start()) [[likely]]
        {
            //
            thread_ = std::thread(std::bind(&resource_builder::periodic_gen_, this));
            //
        }
    }

    [[nodiscard]] inline decltype(auto) building_frequency() const { return metronome_.frequency(); }

    void set_building_frequency(const frequency& freq) requires (!metronome_type::has_constant_frequency)
    {
        metronome_.set_period_frequency(freq, false);
        exec_token_.request_sync();
    }

private:
    void periodic_gen_()
    {
        while (!exec_token_.must_stop()) [[likely]]
        {
            for (metronome_.restart(); exec_token_;) [[likely]]
            {
                // self().run_loop()
                const resource rsc = generator_();
                {
                    std::unique_lock lock(mutex_);
                    available_resources_.push(rsc);
                    if (available_resources_.size() == max_available_resources_)
                        exec_token_.request_pause();
                }
                consume_cv_.notify_one();
                // end self().run_loop()
                std::chrono::nanoseconds dt;
                metronome_.sleep_this_thread(dt);
                std::cout << dt.count() / 1'000'000 << std::endl;
            }
            if (exec_token_.must_pause())
            {
                // self().pause()
                std::unique_lock lock(mutex_);
                const auto pred = [this]{ return available_resources_.size() < max_available_resources_; }; // self_type::resume_requested()
                build_cv_.wait(lock, pred);
                // self().pause()
                exec_token_.finish_pause();
            }
            if (exec_token_.consume_sync())
            {
                // self().sync
                if constexpr (!metronome_type::has_constant_frequency)
                    metronome_.update_period_duration();
                // end self().sync
            }
        }
    }

private:
    execution_token exec_token_;
    metronome_type metronome_;
    resource_generator generator_;
    std::size_t max_available_resources_;
    std::queue<resource> available_resources_;
    std::mutex mutex_;
    std::condition_variable consume_cv_, build_cv_;
    std::thread thread_;
};

void consume_resource(auto& rsc_builder)
{
    std::cout << "consume:\n" << std::flush;
    std::cout << std::format("  {}\n", rsc_builder.request_resource()) << std::flush;
}

int main()
{
    resource_builder rsc_builder([](){
        static std::size_t counter = 0;
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
        ++counter;
        std::cout << std::format("gen: {}", counter) << std::endl;
        return counter;
    }, hertz(3), 4);
    consume_resource(rsc_builder);
    consume_resource(rsc_builder);
    consume_resource(rsc_builder);
    consume_resource(rsc_builder);
    consume_resource(rsc_builder);
    consume_resource(rsc_builder);
    std::cout << "SLEEP" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(2000));
    std::cout << "/SLEEP" << std::endl;
    consume_resource(rsc_builder);
    rsc_builder.stop();
    std::cout << "SLEEP" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(1500));
    std::cout << "/SLEEP" << std::endl;
    rsc_builder.start();
    consume_resource(rsc_builder);
    std::cout << "SLEEP" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(500));
    std::cout << "/SLEEP" << std::endl;
    consume_resource(rsc_builder);

    return EXIT_SUCCESS;
}
