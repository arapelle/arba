#include <iostream>
#include <cstdint>
#include <array>
#include <format>
#include <arba/strn/string64.hpp>

struct bit_balanced_uint64
{
    // clang-format off

    // concat sequence
    static constexpr uint64_t primes_lseq       =  3129231917131175321ull; // 32 '1': 0b0010101101101101010000111101100101101000011010110001010110011001
    static constexpr uint64_t fibonacci_rseq    =  1123581321345589144ull; // 32 '1': 0b0000111110010111110000110100001000111111000100010101111110011000
    static constexpr uint64_t fibonacci_lseq    =  1448955342113853211ull; // 33 '1': 0b0001010000011011101110010011010011101110000110011100111100011011
    // constants digits
    static constexpr uint64_t pi_rdigits        =  3141592653589793238ull; // 33 '1': 0b0010101110011001001011011101111110100010001100100100100111010110
    static constexpr uint64_t pi_ldigits        =  8323979853562951413ull; // 31 '1': 0b0111001110000100101101111001001100010001001000001011011011110101
    static constexpr uint64_t phi_rdigits       = 16180339887498948482ull; // 31 '1': 0b1110000010001100000111010110011010001011011101010110111110000010
    static constexpr uint64_t sqrt2_rdigits     = 14142135623730950488ull; // 32 '1': 0b1100010001000010111101010110101111101001111000010111000101011000
    static constexpr uint64_t sqrt2_ldigits     =  8405903732653124141ull; // 32 '1': 0b0111010010100111110001001110100010010000111010110110101000101101
    static constexpr uint64_t e_rdigits         =  2718281828459045235ull; // 32 '1': 0b0010010110111001010001101110101111000000101100110110000101110011
    static constexpr uint64_t tau_rdigits       =  6283185307179586476ull; // 33 '1': 0b0101011100110010010110111011111101000100011001001001001110101100
    static constexpr uint64_t tau_ldigits       =   746859717035813826ull; // 33 '1': 0b0000101001011101011000001111010010100010111101111110101111000010
    static constexpr uint64_t psi_rdigits       = 14655712318767680266ull; // 31 '1': 0b1100101101100011100011001011010001100010011101101100101100001010

    static constexpr auto all() noexcept
    {
        return std::array<uint64_t, 12>{
            primes_lseq,
            fibonacci_rseq, fibonacci_lseq,
            pi_rdigits,     pi_ldigits,
            phi_rdigits,
            sqrt2_rdigits,  sqrt2_ldigits,
            e_rdigits,
            tau_rdigits,    tau_ldigits,
            psi_rdigits,
        };
    }

    // clang-format on
};

int main()
{
    for (uint64_t x : bit_balanced_uint64::all())
    {
        std::cout << std::format("{: 21d}ull", x) << "; // " << std::popcount(x) << std::format(" '1' 0b{:064b}", x) << std::endl;
    }

    using namespace strn::literals;
    uint64_t name = "anderval"_e64;
    std::cout << std::format("{: 21d}ull", name) << "; // " << std::popcount(name) << std::format(" '1' 0b{:064b}", name) << std::endl;

    return 0;
}
