#include <source_location>
#include <string>
#include <chrono>
#include <arba/cppx/string/fixed_string.hpp>
#include <format>
#include <iostream>

#ifdef NDEBUG
#define ARBA_CPPX_RELEASE_BUILD
#else
#define ARBA_CPPX_DEBUG_BUILD
#endif

struct release_build_t
{
    explicit release_build_t() = default;
    static constexpr std::string_view name() noexcept
    {
        return
#if defined(ARBA_CPPX_RELEASE_BUILD) && defined(ARBA_CPPX_BUILD_TYPE)
            ARBA_CPPX_BUILD_TYPE
#else
            "Release"
#endif
            ;
    }
    static constexpr bool is_debug() noexcept { return false; }
    static constexpr bool is_release() noexcept { return true; }
};
constexpr release_build_t release_build;

struct debug_build_t
{
    explicit debug_build_t() = default;
    static constexpr std::string_view name() noexcept
    {
        return
#if defined(ARBA_CPPX_DEBUG_BUILD) && defined(ARBA_CPPX_BUILD_TYPE)
            ARBA_CPPX_BUILD_TYPE
#else
            "Debug"
#endif
            ;
    }
    static constexpr bool is_debug() noexcept { return true; }
    static constexpr bool is_release() noexcept { return false; }
};
constexpr debug_build_t debug_build;

#ifdef ARBA_CPPX_RELEASE_BUILD
using build_type_t = release_build_t;
#else
using build_type_t = debug_build_t;
#endif
constexpr build_type_t build_type;

template <class BuildT>
concept BuildType = std::is_same_v<BuildT, debug_build_t> || std::is_same_v<BuildT, release_build_t>;

class Level
{
public:
    constexpr Level(unsigned val)
        : value(val)
    {}

    constexpr operator unsigned() const noexcept { return value; }
    constexpr bool enabled() const noexcept { return value > 0 || build_type.is_debug(); }

    unsigned value;
};

class Levels
{
public:
    static constexpr Level debug{0};
    static constexpr Level info{1};

    static constexpr std::array<std::string_view, 2> names{ std::string_view("DEBUG"), std::string_view("INFO") };
};

template <cppx::fixed_string StrV>
consteval auto sv_to_arr()
{
    std::array<char, StrV.size()> res;
    std::copy(StrV.c_str, &StrV.c_str[StrV.size()], res.data());
    return res;
}

template <std::size_t N>
consteval auto transform_arr(const std::array<char, N>& arr)
{
    std::array<char, N> res = arr;
    bool do_fmt = false;
    std::size_t index = 0;
    for (char& ch : res)
    {
        switch (ch)
        {
        case '{':
            if (!do_fmt)
                do_fmt = true;
            else if (arr[index-1] == '{')
                do_fmt = false;
            break;
        case ':':
            if (do_fmt)
                do_fmt = false;
            break;
        case '}':
            if (do_fmt && (index+1 == N || arr[index+1] != '}'))
                do_fmt = false;
            break;
        default:
            if (do_fmt)
                switch (ch)
                {
                case 'l':
                    ch = '0';
                    break;
                case 'D':
                    ch = '1';
                    break;
                case 'g':
                    ch = '2';
                    break;
                case '#':
                    ch = '3';
                    break;
                case '!':
                    ch = '4';
                    break;
                case 'v':
                    ch = '5';
                    break;
                }
        }
        ++index;
    }
    return res;
}

template <std::size_t N>
constexpr auto arr_to_sv(const std::array<char, N>& arr)
{
    return std::string_view(arr.data(), arr.size());
}

constexpr auto str_arr_ = sv_to_arr<"{{voila un message}}:[{l:>8}][{D}][{g}:{#} {!}]: {v}">();
constexpr auto tr_str_arr_ = transform_arr(str_arr_);

template <class MessageT, Level LevelV>
void log(MessageT&& msg, const std::source_location loc = std::source_location::current())
{
    if constexpr (LevelV.enabled())
    {
        const std::chrono::zoned_time zt{"CET", std::chrono::system_clock::now()};
        std::cout << std::format(arr_to_sv(tr_str_arr_),
//                                  std::make_format_args(
                                 Levels::names[LevelV],
                                 zt,
                                 loc.file_name(), loc.line(), loc.function_name(),
                                 std::forward<MessageT>(msg)
//                                      )
                                  )
                  << std::endl;
    }
}

template <class MessageT>
void log(MessageT&& msg, Level lvl, const std::source_location loc = std::source_location::current())
{
    if (lvl.enabled())
    {
        std::cout << std::format(arr_to_sv(tr_str_arr_),
                                 Levels::names[lvl],
                                 loc.file_name(), loc.line(), loc.function_name(),
                                 std::forward<MessageT>(msg))
                  << std::endl;
    }
}

template <class MessageT>
void debug(MessageT&& msg, const std::source_location loc = std::source_location::current())
{
    log<MessageT, Levels::debug>(std::forward<MessageT>(msg), loc);
}

template <class MessageT>
void info(MessageT&& msg, const std::source_location loc = std::source_location::current())
{
    log<MessageT, Levels::info>(std::forward<MessageT>(msg), loc);
}

int main()
{
    debug("debug hello world");
    info("info hello world");
    return EXIT_SUCCESS;
}
